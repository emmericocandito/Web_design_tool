This project relies on the [CubiCasa5k dataset](https://zenodo.org/record/2613548), a collection of 5,000 annotated residential floor plans.
