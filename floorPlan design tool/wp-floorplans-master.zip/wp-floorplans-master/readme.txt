===== WP-Floorplans =====
Contributors: acfoltz, acevans27, bhubbard, imforza
Tags: floor plans, house plans, floorplans
Requires at least: 3.7
Tested up to: 4.3
Stable tag: 1.0.0
License: GP3

WP-Floorplans is a custom WordPress plugin for sites needing to display floor plan information which use WordPress.


== Description ==
WP-Floorplans is a custom WordPress plugin for sites needing to display floor plan information which use WordPress.  It allows them to easily manage each floor plan's galleries and details information on their WordPress website.


== Installation ==
1) Download the plugin
2) Upload to your plugins folder in wp-content
3) Activate the plugin in your WordPress Admin


== FAQ ==
Coming Soon


== Changelog ==

== 1.0.0 ==
* First Release
