def join(args):
    return ", ".join(str(arg) for arg in args)
