*Note: this is internal documentation for the seats.io team*

1) Set the correct version number in setup.py
2) Create the release in GitHub
