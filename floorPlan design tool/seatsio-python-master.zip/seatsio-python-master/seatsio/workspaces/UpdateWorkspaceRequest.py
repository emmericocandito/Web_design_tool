class UpdateWorkspaceRequest:
    def __init__(self, name):
        self.name = name
