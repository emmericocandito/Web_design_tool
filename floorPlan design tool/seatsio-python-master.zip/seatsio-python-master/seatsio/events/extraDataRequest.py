class ExtraDataRequest:
    def __init__(self, extra_data):
        if extra_data:
            self.extraData = extra_data
