# 3D_Modeling
Using Autocad I will make some Project that I have already finished in my EEE154 Course under Akid Ornob(AKO) sir in NSU. Feel free to see my work.
Also, anyone can edit or put comment if you want to. 

I will Upload FLoor Planning (Computer tabla and Chair), Camera, Bottle, Mug, Tire and so on.

## Floor Planning Picture

**Layout**

<img src=https://github.com/SaadAhmedSalim/3D_Modeling/blob/master/Floor%20Planing/Capture.JPG>

**Module**

<img src=https://github.com/SaadAhmedSalim/3D_Modeling/blob/master/Floor%20Planing/computerwithchair.JPG>

-----------------------------------------------------------

## 3D MUG

**Solid**
<img src=https://github.com/SaadAhmedSalim/3D_Modeling/blob/master/MUG/3d%20modeling_MUG.jpg>

**Layout**

<img src=https://github.com/SaadAhmedSalim/3D_Modeling/blob/master/MUG/3d%20modeling_MUG_2dwireframe.jpg>

**Module**

<img src=https://github.com/SaadAhmedSalim/3D_Modeling/blob/master/MUG/3d%20modeling_MUG_module.jpg>

------------------------------------------------------------------------------------------------

## 3D Coca Cola Bottle Designed from 2D sketch 

**2D Sketch**

<img src=https://github.com/SaadAhmedSalim/3D_Modeling/blob/master/Coca%20cola%20Bottle/Coke%20bottle%202d%20sketch.jpg>


**Module**

<img src=https://github.com/SaadAhmedSalim/3D_Modeling/blob/master/Coca%20cola%20Bottle/Coke%20bottle.jpg>

<img src=https://github.com/SaadAhmedSalim/3D_Modeling/blob/master/Coca%20cola%20Bottle/Coke%20bottle_red.jpg>

-------------------------------------------------------------------------------------------

## Iphone Design Template

<img src=https://github.com/SaadAhmedSalim/3D_Modeling/blob/master/IPhone/Iphone.png>

----------------------------------------------------------------------------------------

## Camera Design

**Template**
<img src=https://github.com/SaadAhmedSalim/3D_Modeling/blob/master/Camera/2d%20module%20for%20camera.JPG>

**Module Sketch**
<img src=https://github.com/SaadAhmedSalim/3D_Modeling/blob/master/Camera/module2.JPG>

**Colored Complete**
<img src=https://github.com/SaadAhmedSalim/3D_Modeling/blob/master/Camera/coloredmodule.JPG>

-------------------------------------------------------------------------------------------

## 3D Tire Design

<img src=https://github.com/SaadAhmedSalim/3D_Modeling/blob/master/Tire/complete_tire.png>

**Layout**

<img src=https://github.com/SaadAhmedSalim/3D_Modeling/blob/master/Tire/Wheel%20rim%20with%20tire.png>

**Part by part**

<img src=https://github.com/SaadAhmedSalim/3D_Modeling/blob/master/Tire/wheel%20rim%20part%201.JPG>

<img src=https://github.com/SaadAhmedSalim/3D_Modeling/blob/master/Tire/Wheel%20rim%20part%202.png>

**Module**

<img src=https://github.com/SaadAhmedSalim/3D_Modeling/blob/master/Tire/complete_tire1.png>

--------------------------------------------------------------------------------------
