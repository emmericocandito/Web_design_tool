module.exports = {
  app: {
    files: {
      "dist/<%= pkg.name %>.css": 'src/styles/index.less'
    }
  }
};
