# Apple Pencil In iOS Safari (Pressure.js + P5.js)

This is a minimal demo of a simple drawing tool supporting the Apple Pencil in iOS Safari. The Apple Pencil support comes courtesy of [Pressure.js](https://pressurejs.com/) and all drawing is done using [p5.js](https://p5js.org).

Online demo: https://editor.p5js.org/SableRaf/full/PNSk4uR9v

![Snapshots](https://raw.githubusercontent.com/SableRaf/PencilToP5/master/img/pencilToP5.jpeg)
