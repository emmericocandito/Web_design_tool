# image-merger

A tool that merges popular image formats (jpg, png, svg, gif, etc) into a single file.

# Example

Example #1: Using pure js:
```js
const imageMerger = require('./image-merger');
const fs = require('fs');
const path = require('path');

imageMerger([{
	url: 'https://i.imgflip.com/hirk6.jpg', // cat
	width: 200,
	height: 200,
	x_location: 0,
	y_location: 0
}, {
	url: 'https://static.ezgif.com/images/bg-yellowish.gif', // stickman
	width: 200,
	height: 200,
	x_location: 0,
	y_location: 200
}]).then(result => {
	if (result.isAnimated) {
		fs.writeFileSync(path.join(__dirname, 'animated-result.gif'), result.buffer);
	} else {
		fs.writeFileSync(path.join(__dirname, 'result.png'), result.buffer);
	}
})
```

Example #2: Using typescript:
```js
import imageMerger, { IItemToMerge, IMergeResult } from './image-merger';
import fs from 'fs';
import path from 'path';

const items: Array<IItemToMerge> = [{
	url: 'https://i.imgflip.com/hirk6.jpg', // cat
	width: 200,
	height: 200,
	x_location: 0,
	y_location: 0
}, {
	url: 'https://static.ezgif.com/images/bg-yellowish.gif', // stickman
	width: 200,
	height: 200,
	x_location: 0,
	y_location: 200
}]

imageMerger(items).then((result: IMergeResult) => {
	if (result.isAnimated) {
		fs.writeFileSync(path.join(__dirname, 'animated-result.gif'), result.buffer);
	} else {
		fs.writeFileSync(path.join(__dirname, 'result.png'), result.buffer);
	}
})
```

# Scripts

Installation:
```bash
npm install
```

Building (output in /build):
```bash
npm run build
```

Running tests (output in /build/test/result):
```bash
npm test
```

Development run (builds and runs tests):
```bash
npm run dev
```