import { imageMerger, IItemToMerge, ITEM_TYPES, IMergeResult } from '../src/image-merger';
import writeResultFile from './write-result-file';
import imageSources from './image-sources';

const items: Array<IItemToMerge> = [{
	type: ITEM_TYPES.IMAGE_OR_GIF,
	url: imageSources.jpg.cat,
	width: 200,
	height: 200,
	x_location: 0,
	y_location: 0
}, {
	type: ITEM_TYPES.IMAGE_OR_GIF,
	url: imageSources.gif.stickman,
	width: 200,
	height: 200,
	x_location: 0,
	y_location: 200
}, {
	type: ITEM_TYPES.IMAGE_OR_GIF,
	url: imageSources.gif.cartoon_walk,
	width: 200,
	height: 200,
	x_location: 200,
	y_location: 0
}, {
	type: ITEM_TYPES.IMAGE_OR_GIF,
	url: imageSources.gif.pepe_dance,
	width: 200,
	height: 200,
	x_location: 200,
	y_location: 200
}, {
	type: ITEM_TYPES.IMAGE_OR_GIF,
	url: imageSources.gif.dm_none,
	width: 100,
	height: 100,
	x_location: 0,
	y_location: 0
}, {
	type: ITEM_TYPES.IMAGE_OR_GIF,
	url: imageSources.gif.dm_prev,
	width: 100,
	height: 100,
	x_location: 300,
	y_location: 0
}, {
	type: ITEM_TYPES.IMAGE_OR_GIF,
	url: imageSources.gif.dm_bgnd,
	width: 100,
	height: 100,
	x_location: 300,
	y_location: 300
}, {
	type: ITEM_TYPES.IMAGE_OR_GIF,
	url: imageSources.gif.pepe_clap,
	width: 100,
	height: 100,
	x_location: 150,
	y_location: 150
}]

export default function () {
	imageMerger(items).then((result: IMergeResult) => {
		writeResultFile(result, 'animation-test-result');
	}).catch(error => {
		console.log(error);
	});
}
