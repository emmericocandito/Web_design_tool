import { imageMerger, IItemToMerge, ITEM_TYPES, IMergeResult } from '../src/image-merger';
import writeResultFile from './write-result-file';

const items: Array<IItemToMerge> = [{
	type: ITEM_TYPES.IMAGE_OR_GIF,
	url: 'http://whatever',
	width: 640,
	height: 320,
	x_location: 0,
	y_location: 0
}, {
	type: ITEM_TYPES.IMAGE_OR_GIF,
 	url: 'https://google.com',
 	width: 320,
 	height: 320,
 	x_location: 100,
 	y_location: 100,
}, {
	type: ITEM_TYPES.IMAGE_OR_GIF,
 	url: 'https://site.test/cat.gif',
 	width: 200,
 	height: 200,
 	x_location: 50,
 	y_location: 50
}];

export default function () {
	imageMerger(items).then((result: IMergeResult) => {
		writeResultFile(result, 'error-log-result');
	}).catch(error => {
		console.log(error);
	});
}