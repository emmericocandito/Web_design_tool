import { imageMerger, IItemToMerge, ITEM_TYPES, IMergeResult } from '../src/image-merger';
import writeResultFile from './write-result-file';
import imageSources from './image-sources';

const items: Array<IItemToMerge> = [{
	type: ITEM_TYPES.IMAGE_OR_GIF,
	url: imageSources.gif.cat,
	width: 200,
	height: 200,
	x_location: 0,
	y_location: 0
}, {
	type: ITEM_TYPES.IMAGE_OR_GIF,
	url: imageSources.dataUrl.pepe,
	width: 100,
	height: 100,
	x_location: 50,
	y_location: 200
}]

export default function () {
	imageMerger(items).then((result: IMergeResult) => {
		writeResultFile(result, 'data-url-test-result');
	}).catch(error => {
		console.log(error);
	});
}