import { imageMerger, IItemToMerge, ITEM_TYPES, IMergeResult } from '../src/image-merger';
import writeResultFile from './write-result-file';
import imageSources from './image-sources';

const items: Array<IItemToMerge> = [{
	type: ITEM_TYPES.IMAGE_OR_GIF,
	url: imageSources.jpg.cat,
	width: 400,
	height: 400,
	x_location: 0,
	y_location: 0
}, {
	type: ITEM_TYPES.IMAGE_OR_GIF,
	url: imageSources.svg.crown,
	width: 150,
	height: 125,
	x_location: 100,
	y_location: 0
}, {
	type: ITEM_TYPES.IMAGE_OR_GIF,
	url: imageSources.svg.error,
	width: 125,
	height: 125,
	x_location: 400,
	y_location: 150
}, {
	type: ITEM_TYPES.IMAGE_OR_GIF,
	url: imageSources.png.user_icon,
	width: 100,
	height: 100,
	x_location: 0,
	y_location: 200
}];

export default function () {
	imageMerger(items).then((result: IMergeResult) => {
		writeResultFile(result, 'image-test-result');
	}).catch(error => {
		console.log(error);
	});
}