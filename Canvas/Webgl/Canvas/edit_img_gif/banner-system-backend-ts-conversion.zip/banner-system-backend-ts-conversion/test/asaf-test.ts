import { imageMerger, IItemToMerge, ITEM_TYPES, IMergeResult } from '../src/image-merger';
import writeResultFile from './write-result-file';
import imageSources from './image-sources';

const items: Array<IItemToMerge> = [{
	type: ITEM_TYPES.IMAGE_OR_GIF,
	url: 'https://images1.calcalist.co.il/PicServer3/2017/04/24/720257/1LM.gif',
	width: 640,
	height: 320,
	x_location: 0,
	y_location: 0
}, {
	type: ITEM_TYPES.IMAGE_OR_GIF,
 	url: 'https://images1.calcalist.co.il/PicServer3/2017/04/24/720257/1LM.gif',
 	width: 320,
 	height: 320,
 	x_location: 100,
 	y_location: 100,
}, {
	type: ITEM_TYPES.IMAGE_OR_GIF,
 	url: 'https://specials-images.forbesimg.com/dam/imageserve/1137653208%2F960x0.jpg',
 	width: 200,
 	height: 200,
 	x_location: 50,
 	y_location: 50
}];

const items2: Array<IItemToMerge> = [{
	type: ITEM_TYPES.IMAGE_OR_GIF,
	url: 'https://specials-images.forbesimg.com/dam/imageserve/1137653208%2F960x0.jpg',
	x_location: 0,
	y_location: 0,
	width: 640,
	height: 320,
}, {
	type: ITEM_TYPES.IMAGE_OR_GIF,
	url: 'https://www.fonedog.com/images/photo-compress/compress-image-online-compression.png',
	x_location: 100,
	y_location: 100,
	width: 320,
	height: 320,
}, {
	type: ITEM_TYPES.IMAGE_OR_GIF,
	url: 'https://specials-images.forbesimg.com/dam/imageserve/1137653208%2F960x0.jpg',
	x_location: 50,
	y_location: 50,
	width: 200,
	height: 200,
}, {
	type: ITEM_TYPES.IMAGE_OR_GIF,
	url: 'https://dev.w3.org/SVG/tools/svgweb/samples/svg-files/car.svg',
	x_location: 0,
	y_location: 0,
	width: 90,
	height: 60,
}];

export default function () {
	imageMerger(items).then((result: IMergeResult) => {
		writeResultFile(result, 'asaf-test-result1');
	}).catch(error => {
		console.log(error);
	});

	imageMerger(items2).then((result: IMergeResult) => {
		writeResultFile(result, 'asaf-test-result2');
	}).catch(error => {
		console.log(error);
	});

	// imageMerger(items3).then((result: IMergeResult) => {
	// 	writeResultFile(result, 'asaf-test-result3');
	// }).catch(error => {
	// 	console.log(error);
	// });
}