import fs from 'fs';
import path from 'path';

const dir = path.join(__dirname, 'result');

if (fs.existsSync(dir)) {
	fs.rmdirSync(dir, { recursive: true });
}

// import errorLogTest from './error-log-test';
// errorLogTest();

import animationTest from './animation-test';
animationTest();

import imageTest from './image-test';
imageTest();

// import brokenUrlTest from './broken-url-test';
// brokenUrlTest();

import dataUrlTest from './data-url-test';
dataUrlTest();

import asafTest from './asaf-test';
asafTest();
