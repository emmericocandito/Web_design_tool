import { imageMerger, IItemToMerge, ITEM_TYPES, IMergeResult } from '../src/image-merger';
import writeResultFile from './write-result-file';

const items: Array<IItemToMerge> = [{
	type: ITEM_TYPES.IMAGE_OR_GIF,
	url: "https://wtf",
	width: 100,
	height: 100,
	x_location: 0,
	y_location: 0
}]

export default function () {
	imageMerger(items).then((result: IMergeResult) => {
		writeResultFile(result, 'broken-url-test-result');
	}).catch(error => {
		console.log(error);
	});
}