// http://www.imagemagick.org/Usage/anim_basics/#previous
import gifFrames, { GifFrameData, GifFrameOptions } from 'gif-frames';
import GIFEncoder from 'gifencoder';
import { createCanvas, Image } from 'canvas';
import request from 'request';
import { CSSProperties } from 'react';
import url from 'url';
// import path from 'path';

// TODO: replace all the "any" types to their true types

export enum ITEM_TYPES {
	IMAGE_OR_GIF = "I",
	TEXT = "T",
	BACKGROUND = "B",
}

interface IItemToMerge_BASIC {
	type: ITEM_TYPES,
	x_location: number,
	y_location: number,
	width: number,
}

export interface IItemToMerge_IMAGE_OR_GIF extends IItemToMerge_BASIC {
	type: ITEM_TYPES.IMAGE_OR_GIF,
	url: string,
	height: number,
};

export interface IItemToMerge_TEXT extends IItemToMerge_BASIC {
	type: ITEM_TYPES.TEXT,
	text: string,
	cssProperties: CSSProperties,
};

export interface IItemToMerge_BACKGROUND extends IItemToMerge_BASIC {
	type: ITEM_TYPES.BACKGROUND,
	color: string,
	height: number,
};

export type IItemToMerge = IItemToMerge_IMAGE_OR_GIF | IItemToMerge_TEXT | IItemToMerge_BACKGROUND;


enum PARSED_ITEM_TYPES {
	GIF = "GIF",
	IMAGE = "IMAGE",
}

interface IParsedItem_BASIC {
	itemType: PARSED_ITEM_TYPES,
	order: number,
	xPos: number,
	yPos: number,
	width: number,
	height: number
}

interface IParsedItem_IMAGE extends IParsedItem_BASIC {
	itemType: PARSED_ITEM_TYPES.IMAGE,
	image: Image,
}

interface ITimelinePlaceholder {
	[key: number]: number,
}
interface ITimelinePlaceholder_Booleans {
	[key: number]: boolean,
}
interface IParsedItem_GIF extends IParsedItem_BASIC {
	itemType: PARSED_ITEM_TYPES.GIF,
	frameData: any,
	lastAddedFrame: number,
}

interface IGifItem extends IParsedItem_GIF {
	timelinePlaceholder: ITimelinePlaceholder,
}

type IParsedItem = IParsedItem_IMAGE | IParsedItem_GIF;

export interface IMergeResult {
	buffer: Buffer,
	isAnimated: boolean
}

function _getFrameImage(frame: any): Promise<Image> {
	return new Promise((resolve, reject) => {
		const stream = frame.getImage();
		const buffers: Uint8Array[] = [];
		stream.on('data', (buffer: Uint8Array) => {
			buffers.push(buffer);
		});
		stream.on('end', () => {
			const buffer = Buffer.concat(buffers);
			const image = new Image();
			image.onload = function () {
				resolve(image);
			}
			image.onerror = function () {
				// @ts-ignore
				reject(result); // TODO: What is result?? (remove "// @ts-ignore" to see the error)
			}
			image.src = buffer;
		});
		stream.on('error', (error: Error) => {
			reject(error)
		});
	});
}

function _flattenFrames(frameData: any[], width: number, height: number) {
	const lastCanvas = createCanvas(width, height);
	const lastCtx = lastCanvas.getContext('2d');
	let imagesToFlatten = frameData.length;
	let imagesFlattened = 0;
	for (let i = 0; i < frameData.length; i++) {
		let frame = frameData[i];
		let disposal = frame.frameInfo.disposal;

		const flattenedCanvas = createCanvas(width, height);
		const flattenedCtx = flattenedCanvas.getContext('2d');
		flattenedCtx.drawImage(lastCanvas, 0, 0, width, height);
		flattenedCtx.drawImage(frame.image, 0, 0, width, height);
		frame.flattenedCanvas = flattenedCanvas;

		if (disposal === 0 || disposal === 1) { // preserve drawing
			lastCtx.drawImage(flattenedCanvas, 0, 0, width, height);
		} else if (disposal === 2) { // reset to background
			const tempCanvas = createCanvas(width, height);
			const tempCtx = tempCanvas.getContext('2d');
			tempCtx.drawImage(frame.image, 0, 0, width, height);
			lastCtx.save();
			lastCtx.globalCompositeOperation = 'destination-out';
			lastCtx.drawImage(tempCanvas, 0, 0, width, height);
			lastCtx.restore();
		} else if (disposal === 3) { // reset to previous
			// doesn't need anything
		}
	}
}

function _compileFrameData(frameData: any[], width: number, height: number) {
	return new Promise((resolve, reject) => {
		let framesLoaded = 0;
		let framesToLoad = frameData.length;
		for (let i = 0; i < frameData.length; i++) {
			const frame = frameData[ i ];
			_getFrameImage(frame).then((image) => {
				frame.image = image;
				framesLoaded++;
				if (framesLoaded === framesToLoad) {
					_flattenFrames(frameData, width, height);
					resolve();
				}
			}).catch((error) => {
				console.error('_compileFrameData - ERROR: '+error.stack);
				reject(error);
			});
		}
	});
}

// function createGifFromCompiledFrameData(frameData, width, height) {
// 	const canvas = createCanvas(width, height);
// 	const ctx = canvas.getContext('2d');
// 	const encoder = new GIFEncoder(width, height);
// 	encoder.setQuality(10);
// 	encoder.setRepeat(0);
// 	encoder.start();
// 	for (let j = 0; j < frameData.length; j++) {
// 		const frame = frameData[j];
// 		ctx.drawImage(frame.flattenedCanvas, 0, 0, width, height);
// 		encoder.setDelay(frame.frameInfo.delay * 10);
// 		encoder.addFrame(ctx);
// 	}
// 	encoder.finish();
// 	const buffer = encoder.out.getData();
// 	return buffer;
// }

function _loadCompiledFrameData(url: string, width: number, height: number): Promise<any> {
	return new Promise((resolve, reject) => {
		const options: GifFrameOptions = {
			url: url,
			frames: 'all',
			cumulative: false,
			outputType: 'png'
		}
		gifFrames(options).then(function (frameData: any) {
			_compileFrameData(frameData, width, height).then(() => {
				resolve(frameData);
			}).catch((error) => {
				console.error('_loadCompiledFrameData - ERROR: '+error.stack);
				reject(error);
			});
		});
	});
}

let emptyResult: any;

function _createEmptyResult() {
	let canvas = createCanvas(1, 1);
	let ctx = canvas.getContext('2d');
	ctx.fillStyle = '#000';
	ctx.fillRect(0, 0, 1, 1);
	emptyResult = {
		isPng: true,
		buffer: canvas.toBuffer('image/png')
	}
}

function _getContentType(url: string): Promise<string> {
	return new Promise((resolve, reject) => {
		if (url.substr(0, 4).toLowerCase() === 'data') {
			const contentType = url.substring(url.indexOf(":") + 1, url.indexOf(";"));
			resolve(contentType);
		} else {
			let req = request.get(url);
			req.on('response', (res) => {
				const contentType = res.headers['content-type'];
				req.abort();
				resolve(contentType);
			});
			req.on('error', reject);
		}
	});
}

function _mergeParsedItems(items: IParsedItem[]) {
	if (items.length === 0) {
		if (!emptyResult) {
			_createEmptyResult();
		}
		return emptyResult;
	}

	items = items.sort((a, b) => a.order - b.order);
	let gifItems: IGifItem[] = [];
	let width = 0;
	let height = 0;
	for (let i = 0; i < items.length; i++) {
		let item = items[i];
		width = Math.max(item.xPos + item.width, width);
		height = Math.max(item.yPos + item.height, height);
		if (item.itemType === PARSED_ITEM_TYPES.GIF) {
			gifItems.push({
				...item,
				timelinePlaceholder: {},
			});
		}
	}

	// Fix zero duration cases
	for (let i = 0; i < gifItems.length; i++) {
		let gifItem = gifItems[i];
		let duration = 0;
		for (let j = 0; j < gifItem.frameData.length; j++) {
			let frame = gifItem.frameData[j];
			duration += frame.frameInfo.delay;
		}
		if (duration === 0) {
			for (let j = 0; j < gifItem.frameData.length; j++) {
				let frame = gifItem.frameData[j];
				frame.frameInfo.delay = 1;
			}
		}
	}

	// 1) Forming the universal timeline and partial local timelines
	const timelinePlaceholder: ITimelinePlaceholder_Booleans = {};
	let maxDuration = 0;
	for (let i = 0; i < gifItems.length; i++) {
		let gifItem = gifItems[i];
		let duration = 0;
		for (let j = 0; j < gifItem.frameData.length; j++) {
			const frame = gifItem.frameData[j];
			if (frame.frameInfo.delay === 0) {
				gifItem.frameData.splice(j, 1);
				j--;
				continue;
			}
			// duration += frame.frameInfo.delay;
			// timelinePlaceholder[duration] = true;
			// gifItem.timelinePlaceholder[duration] = j;
			timelinePlaceholder[duration] = true;
			gifItem.timelinePlaceholder[duration] = j;
			duration += frame.frameInfo.delay;
			maxDuration = Math.max(maxDuration, duration);
		}
		// console.debug('Partial timeline placeholder:', gifItem.timelinePlaceholder);
	}
	const timeline = Object.keys(timelinePlaceholder).map(x => parseInt(x)).sort((a, b) => a - b);
	// console.debug(timeline);

	// 2) Filling out partial local timelines
	for (let i = 0; i < gifItems.length; i++) {
		let gifItem = gifItems[i];
		let lastOnTimelineFrameIndex = 0;
		for (let j = 0; j < timeline.length; j++) {
			let timelineValue = timeline[j];
			let prevFrameIndex = gifItem.timelinePlaceholder[timelineValue];
			if (prevFrameIndex !== undefined) {
				lastOnTimelineFrameIndex = parseInt(""+prevFrameIndex);
			} else if (lastOnTimelineFrameIndex !== gifItem.frameData.length - 1 || true) {
				gifItem.timelinePlaceholder[timelineValue] = lastOnTimelineFrameIndex;
			}
		}
		// console.debug('Number of frames', gifItem.frameData.length);
		// console.debug('timelinePlaceholder', gifItem.timelinePlaceholder);
	}

	const canvas = createCanvas(width, height);
	const ctx = canvas.getContext('2d');
	if (gifItems.length === 0) {
		for (let i = 0; i < items.length; i++) {
			const item = items[i];
			ctx.drawImage((item as IParsedItem_IMAGE).image, item.xPos, item.yPos, item.width, item.height);
		}
		let buffer = canvas.toBuffer('image/png');
		return {
			isAnimated: false,
			buffer: buffer
		};
	} else {
		const encoder = new GIFEncoder(width, height);
		encoder.setQuality(10);
		encoder.setRepeat(0);
		// Transparency wouldn't work :(
		// encoder.setTransparent(0x0026fa)
		encoder.start();
		// let lastTimelineValue = 0;
		for (let i = 0; i < timeline.length; i++) {
			let timelineValue: number = timeline[i];
			// console.debug('Adding frame at t:', timelineValue);
			ctx.clearRect(0, 0, width, height);
			for (let j = 0; j < items.length; j++) {
				let item = items[j];
				if (item.itemType === PARSED_ITEM_TYPES.GIF) {
					let frameIndex = (item as IGifItem).timelinePlaceholder[timelineValue];
					let frame = item.frameData[frameIndex];
					if (frame) {
						ctx.drawImage(frame.flattenedCanvas, item.xPos, item.yPos, item.width, item.height);
					}
				} else {
					ctx.drawImage(item.image, item.xPos, item.yPos, item.width, item.height);
				}
			}
			let nextTimelineValue = (i === timeline.length - 1 ? maxDuration : timeline[i + 1]);
			let delay = nextTimelineValue - timelineValue;
			// let delay = timelineValue - lastTimelineValue;
			// lastTimelineValue = timelineValue;
			encoder.setDelay(delay * 10);
			encoder.addFrame(ctx);
		}
		encoder.finish();
		// @ts-ignore
		const buffer = encoder.out.getData(); // TODO: Solve error: TS2339: Property 'out' does not exist on type 'GIFEncoder'. (remove "// @ts-ignore" to see the error)
		return {
			isAnimated: true,
			buffer: buffer
		};
	}
}

export function imageMerger(items: Array<IItemToMerge>): Promise<IMergeResult> {
	return new Promise((resolve, reject) => {
		let itemsToLoad = items.length;
		let itemsLoaded = 0;
		let parsedItems: IParsedItem[] = [];
		// let gifItems = [];
		for (let i = 0; i < items.length; i++) {
			let item: IItemToMerge_IMAGE_OR_GIF = (items[i] as IItemToMerge_IMAGE_OR_GIF); // TOOD: Need to check type first
			// let pathname = url.parse(item.image_url).pathname;
			_getContentType(item.url).then(contentType => {

				if (contentType == 'image/gif') {
					_loadCompiledFrameData(item.url, item.width, item.height).then((frameData) => {
						parsedItems.push({
							itemType: PARSED_ITEM_TYPES.GIF,
							order: i,
							frameData: frameData,
							lastAddedFrame: -1,
							xPos: item.x_location,
							yPos: item.y_location,
							width: item.width,
							height: item.height
						});
						incrementItemsLoaded();
					}).catch((error) => {
						console.error('Failed load item. url=' + item.url+'\nError='+error.stack);
						incrementItemsLoaded();
					});
				} else {
					const image = new Image();
					image.onload = function () {
						const parsedItem: IParsedItem_IMAGE = {
							itemType: PARSED_ITEM_TYPES.IMAGE,
							order: i,
							image: image,
							xPos: item.x_location,
							yPos: item.y_location,
							width: item.width,
							height: item.height
						};
						parsedItems.push(parsedItem);
						incrementItemsLoaded();
					}
					image.onerror = function (error) {
						console.error(`image.onerror - The URL response\'s content is not a valid image! Failed load item. URL=${item.url}, Error=${error.stack}`);
						incrementItemsLoaded();
					}
					image.src = item.url;
				}
			}).catch((error) => {
				console.error(`'getContentType' (inside 'mergeImages') - Error retrieving the content and its type. Probably due to invlid/broken URL (URL=${item.url}), Error=${error.stack}`);
				incrementItemsLoaded();
			});
		}
		function incrementItemsLoaded() {
			itemsLoaded++;
			if (itemsLoaded === itemsToLoad) {
				resolve(_mergeParsedItems(parsedItems));
			}
		}
	});
}
