import imageMerger, { MergeItem, MergeResult } from '../src/image-merger';
import writeResultFile from './write-result-file';
import imageSources from './image-sources';

const items: Array<MergeItem> = [{
	image_url: imageSources.jpg.cat,
	image_width: 200,
	image_height: 200,
	image_x_location: 0,
	image_y_location: 0
}, {
	image_url: imageSources.gif.pepe_dance,
	image_width: 200,
	image_height: 200,
	image_x_location: 0,
	image_y_location: 200
}, {
	image_url: imageSources.gif.cartoon_walk,
	image_width: 200,
	image_height: 200,
	image_x_location: 200,
	image_y_location: 0
}, {
	image_url: imageSources.gif.pepe_dance,
	image_width: 200,
	image_height: 200,
	image_x_location: 200,
	image_y_location: 200
}, {
	image_url: imageSources.gif.dm_none,
	image_width: 100,
	image_height: 100,
	image_x_location: 0,
	image_y_location: 0
}, {
	image_url: imageSources.gif.dm_prev,
	image_width: 100,
	image_height: 100,
	image_x_location: 300,
	image_y_location: 0
}, {
	image_url: imageSources.gif.dm_bgnd,
	image_width: 100,
	image_height: 100,
	image_x_location: 300,
	image_y_location: 300
}, {
	image_url: imageSources.gif.pepe_clap,
	image_width: 100,
	image_height: 100,
	image_x_location: 150,
	image_y_location: 150
}]

export default function () {
	imageMerger(items).then((result: MergeResult) => {
		writeResultFile(result, 'animation-test-result');
	}).catch(error => {
		console.log(error);
	});
}
