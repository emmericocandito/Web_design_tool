import fs from 'fs';
import path from 'path';
import { MergeResult } from '../src/image-merger';

const dir = path.join(__dirname, 'result');

export default function writeResultFile(result: MergeResult, name: string) {
	if (!fs.existsSync(dir)) {
		fs.mkdirSync(dir);
	}
	if (result.isAnimated) {
		fs.writeFileSync(path.join(dir, name + '.gif'), result.buffer);
	} else {
		fs.writeFileSync(path.join(dir, name + '.png'), result.buffer);
	}
}
