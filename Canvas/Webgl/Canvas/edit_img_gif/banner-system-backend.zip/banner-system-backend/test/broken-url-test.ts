import imageMerger, { MergeItem, MergeResult } from '../src/image-merger';
import writeResultFile from './write-result-file';

const items: Array<MergeItem> = [{
	image_url: "https://wtf",
	image_width: 100,
	image_height: 100,
	image_x_location: 0,
	image_y_location: 0
}]

export default function () {
	console.log('The following exceptions are intentional for testing purposes!');
	imageMerger(items).then((result: MergeResult) => {
		writeResultFile(result, 'broken-url-test-result');
	}).catch(error => {
		console.log(error);
	});
}