import imageMerger, { MergeItem, MergeResult } from '../src/image-merger';
import writeResultFile from './write-result-file';

const items: Array<MergeItem> = [{
	image_url: 'http://whatever',
	image_width: 640,
	image_height: 320,
	image_x_location: 0,
	image_y_location: 0
}, {
 	image_url: 'https://google.com',
 	image_width: 320,
 	image_height: 320,
 	image_x_location: 100,
 	image_y_location: 100,
}, {
 	image_url: 'https://site.test/cat.gif',
 	image_width: 200,
 	image_height: 200,
 	image_x_location: 50,
 	image_y_location: 50
}];

export default function () {
	console.log('The following exceptions are intentional for testing purposes!');
	imageMerger(items).then((result: MergeResult) => {
		writeResultFile(result, 'error-log-result');
	}).catch(error => {
		console.log(error);
	});
}