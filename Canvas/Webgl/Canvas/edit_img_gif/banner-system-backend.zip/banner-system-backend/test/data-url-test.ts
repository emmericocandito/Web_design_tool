import imageMerger, { MergeItem, MergeResult } from '../src/image-merger';
import writeResultFile from './write-result-file';
import imageSources from './image-sources';

const items: Array<MergeItem> = [{
	image_url: imageSources.gif.cat,
	image_width: 200,
	image_height: 200,
	image_x_location: 0,
	image_y_location: 0
}, {
	image_url: imageSources.dataUrl.pepe,
	image_width: 100,
	image_height: 100,
	image_x_location: 50,
	image_y_location: 200
}]

export default function () {
	imageMerger(items).then((result: MergeResult) => {
		writeResultFile(result, 'data-url-test-result');
	}).catch(error => {
		console.log(error);
	});
}