import imageMerger, { MergeItem, MergeResult } from '../src/image-merger';
import writeResultFile from './write-result-file';
import imageSources from './image-sources';

const items: Array<MergeItem> = [{
	image_url: imageSources.jpg.cat,
	image_width: 400,
	image_height: 400,
	image_x_location: 0,
	image_y_location: 0
}, {
	image_url: imageSources.svg.crown,
	image_width: 150,
	image_height: 125,
	image_x_location: 100,
	image_y_location: 0
}, {
	image_url: imageSources.svg.error,
	image_width: 125,
	image_height: 125,
	image_x_location: 400,
	image_y_location: 150
}, {
	image_url: imageSources.png.user_icon,
	image_width: 100,
	image_height: 100,
	image_x_location: 0,
	image_y_location: 200
}];

export default function () {
	imageMerger(items).then((result: MergeResult) => {
		writeResultFile(result, 'image-test-result');
	}).catch(error => {
		console.log(error);
	});
}