import imageMerger, { MergeItem, MergeResult } from '../src/image-merger';
import writeResultFile from './write-result-file';
import imageSources from './image-sources';

const items: Array<MergeItem> = [{
	image_url: 'https://images1.calcalist.co.il/PicServer3/2017/04/24/720257/1LM.gif',
	image_width: 640,
	image_height: 320,
	image_x_location: 0,
	image_y_location: 0
}, {
 	image_url: 'https://images1.calcalist.co.il/PicServer3/2017/04/24/720257/1LM.gif',
 	image_width: 320,
 	image_height: 320,
 	image_x_location: 100,
 	image_y_location: 100,
}, {
 	image_url: 'https://specials-images.forbesimg.com/dam/imageserve/1137653208%2F960x0.jpg',
 	image_width: 200,
 	image_height: 200,
 	image_x_location: 50,
 	image_y_location: 50
}];

const items2: Array<MergeItem> = [{
	image_url: 'https://specials-images.forbesimg.com/dam/imageserve/1137653208%2F960x0.jpg',
	image_x_location: 0,
	image_y_location: 0,
	image_width: 640,
	image_height: 320,
}, {
	image_url: 'https://www.fonedog.com/images/photo-compress/compress-image-online-compression.png',
	image_x_location: 100,
	image_y_location: 100,
	image_width: 320,
	image_height: 320,
}, {
	image_url: 'https://specials-images.forbesimg.com/dam/imageserve/1137653208%2F960x0.jpg',
	image_x_location: 50,
	image_y_location: 50,
	image_width: 200,
	image_height: 200,
}, {
	image_url: 'https://dev.w3.org/SVG/tools/svgweb/samples/svg-files/car.svg',
	image_x_location: 0,
	image_y_location: 0,
	image_width: 90,
	image_height: 60,
}];

export default function () {
	imageMerger(items).then((result: MergeResult) => {
		writeResultFile(result, 'asaf-test-result1');
	}).catch(error => {
		console.log(error);
	});

	imageMerger(items2).then((result: MergeResult) => {
		writeResultFile(result, 'asaf-test-result2');
	}).catch(error => {
		console.log(error);
	});
}