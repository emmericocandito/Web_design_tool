// http://www.imagemagick.org/Usage/anim_basics/#previous
const gifFrames = require('gif-frames');
const GIFEncoder = require('gifencoder');
const { createCanvas, Image } = require('canvas');
const request = require('request');
const url = require('url');
const path = require('path');

function getFrameImage(frame) {
	return new Promise((resolve, reject) => {
		const stream = frame.getImage();
		const buffers = [];
		stream.on('data', (buffer) => {
			buffers.push(buffer);
		});
		stream.on('end', () => {
			const buffer = Buffer.concat(buffers);
			const image = new Image();
			image.onload = function () {
				resolve(image);
			}
			image.onerror = function () {
				reject(result);
			}
			image.src = buffer;
		});
		stream.on('error', (error) => {
			reject(error)
		});
	});
}

function flattenFrames(frameData, width, height) {
	const lastCanvas = createCanvas(width, height);
	const lastCtx = lastCanvas.getContext('2d');
	let imagesToFlatten = frameData.length;
	let imagesFlattened = 0;
	for (let i = 0; i < frameData.length; i++) {
		let frame = frameData[i];
		let disposal = frame.frameInfo.disposal;

		const flattenedCanvas = createCanvas(width, height);
		const flattenedCtx = flattenedCanvas.getContext('2d');
		flattenedCtx.drawImage(lastCanvas, 0, 0, width, height);
		flattenedCtx.drawImage(frame.image, 0, 0, width, height);
		frame.flattenedCanvas = flattenedCanvas;

		if (disposal === 0 || disposal === 1) { // preserve drawing
			lastCtx.drawImage(flattenedCanvas, 0, 0, width, height);
		} else if (disposal === 2) { // reset to background
			const tempCanvas = createCanvas(width, height);
			const tempCtx = tempCanvas.getContext('2d');
			tempCtx.drawImage(frame.image, 0, 0, width, height);
			lastCtx.save();
			lastCtx.globalCompositeOperation = 'destination-out';
			lastCtx.drawImage(tempCanvas, 0, 0, width, height);
			lastCtx.restore();
		} else if (disposal === 3) { // reset to previous
			// doesn't need anything
		}
	}
}

function compileFrameData(frameData, width, height) {
	return new Promise((resolve, reject) => {
		let framesLoaded = 0;
		let framesToLoad = frameData.length;
		for (let i = 0; i < frameData.length; i++) {
			const frame = frameData[ i ];
			getFrameImage(frame).then((image) => {
				frame.image = image;
				framesLoaded++;
				if (framesLoaded === framesToLoad) {
					flattenFrames(frameData, width, height);
					resolve();
				}
			}).catch((error) => {
				console.error('compileFrameData - ERROR: '+error.stack);
				reject(error);
			});
		}
	});
}

function createGifFromCompiledFrameData(frameData, width, height) {
	const canvas = createCanvas(width, height);
	const ctx = canvas.getContext('2d');
	const encoder = new GIFEncoder(width, height);
	encoder.setQuality(10);
	encoder.setRepeat(0);
	encoder.start();
	for (let j = 0; j < frameData.length; j++) {
		const frame = frameData[j];
		ctx.drawImage(frame.flattenedCanvas, 0, 0, width, height);
		encoder.setDelay(frame.frameInfo.delay * 10);
		encoder.addFrame(ctx);
	}
	encoder.finish();
	const buffer = encoder.out.getData();
	return buffer;
}

function loadCompiledFrameData(url, width, height) {
	return new Promise((resolve, reject) => {
		gifFrames({
			url: url,
			frames: 'all',
			cumulative: false,
			outputType: 'png'
		}).then(function (frameData) {
			compileFrameData(frameData, width, height).then(() => {
				resolve(frameData);
			}).catch((error) => {
				console.error('loadCompiledFrameData - ERROR: '+error.stack);
				reject(error);
			});
		});
	});
}

let emptyResult;

function createEmptyResult() {
	let canvas = createCanvas(1, 1);
	let ctx = canvas.getContext('2d');
	ctx.fillStyle = '#000';
	ctx.fillRect(0, 0, 1, 1);
	emptyResult = {
		isPng: true,
		buffer: canvas.toBuffer('image/png')
	}
}

function getContentType(url) {
	return new Promise((resolve, reject) => {
		if (url.substr(0, 4).toLowerCase() === 'data') {
			const contentType = url.substring(url.indexOf(":") + 1, url.indexOf(";"));
			resolve(contentType);
		} else {
			let req = request.get(url);
			req.on('response', (res) => {
				const contentType = res.headers['content-type'];
				req.abort();
				resolve(contentType);
			});
			req.on('error', reject);
		}
	});
}

function mergeParsedItems(items) {
	if (items.length === 0) {
		if (!emptyResult) {
			createEmptyResult();
		}
		return emptyResult;
	}

	items = items.sort((a, b) => a.order - b.order);
	let gifItems = [];
	let width = 0;
	let height = 0;
	for (let i = 0; i < items.length; i++) {
		let item = items[i];
		width = Math.max(item.xPos + item.width, width);
		height = Math.max(item.yPos + item.height, height);
		if (item.isGifItem) {
			gifItems.push(item);
		}
	}

	// Fix zero duration cases
	for (let i = 0; i < gifItems.length; i++) {
		let gifItem = gifItems[i];
		let duration = 0;
		for (let j = 0; j < gifItem.frameData.length; j++) {
			let frame = gifItem.frameData[j];
			duration += frame.frameInfo.delay;
		}
		if (duration === 0) {
			for (let j = 0; j < gifItem.frameData.length; j++) {
				let frame = gifItem.frameData[j];
				frame.frameInfo.delay = 1;
			}
		}
	}

	// 1) Forming the universal timeline and partial local timelines
	const timelinePlaceholder = {};
	let maxDuration = 0;
	for (let i = 0; i < gifItems.length; i++) {
		let gifItem = gifItems[i];
		gifItem.timelinePlaceholder = {};
		let duration = 0;
		for (let j = 0; j < gifItem.frameData.length; j++) {
			const frame = gifItem.frameData[j];
			if (frame.frameInfo.delay === 0) {
				gifItem.frameData.splice(j, 1);
				j--;
				continue;
			}
			// duration += frame.frameInfo.delay;
			// timelinePlaceholder[duration] = true;
			// gifItem.timelinePlaceholder[duration] = j;
			timelinePlaceholder[duration] = true;
			gifItem.timelinePlaceholder[duration] = j;
			duration += frame.frameInfo.delay;
			maxDuration = Math.max(maxDuration, duration);
		}
		// console.debug('Partial timeline placeholder:', gifItem.timelinePlaceholder);
	}
	const timeline = Object.keys(timelinePlaceholder).map(x => parseInt(x)).sort((a, b) => a - b);
	// console.debug(timeline);

	// 2) Filling out partial local timelines
	for (let i = 0; i < gifItems.length; i++) {
		let gifItem = gifItems[i];
		let lastOnTimelineFrameIndex = 0;
		for (let j = 0; j < timeline.length; j++) {
			let timelineValue = timeline[j];
			let prevFrameIndex = gifItem.timelinePlaceholder[timelineValue];
			if (prevFrameIndex !== undefined) {
				lastOnTimelineFrameIndex = parseInt(prevFrameIndex);
			} else if (lastOnTimelineFrameIndex !== gifItem.frameData.length - 1 || true) {
				gifItem.timelinePlaceholder[timelineValue] = lastOnTimelineFrameIndex;
			}
		}
		// console.debug('Number of frames', gifItem.frameData.length);
		// console.debug('timelinePlaceholder', gifItem.timelinePlaceholder);
	}

	const canvas = createCanvas(width, height);
	const ctx = canvas.getContext('2d');
	if (gifItems.length === 0) {
		for (let i = 0; i < items.length; i++) {
			const item = items[i];
			ctx.drawImage(item.image, item.xPos, item.yPos, item.width, item.height);
		}
		let buffer = canvas.toBuffer('image/png');
		return {
			isAnimated: false,
			buffer: buffer
		};
	} else {
		const encoder = new GIFEncoder(width, height);
		encoder.setQuality(10);
		encoder.setRepeat(0);
		// Transparency wouldn't work :(
		// encoder.setTransparent(0x0026fa)
		encoder.start();
		let lastTimelineValue = 0;
		for (let i = 0; i < timeline.length; i++) {
			let timelineValue = timeline[i];
			// console.debug('Adding frame at t:', timelineValue);
			ctx.clearRect(0, 0, width, height);
			for (let j = 0; j < items.length; j++) {
				let item = items[j];
				if (item.isGifItem) {
					let frameIndex = item.timelinePlaceholder[timelineValue];
					let frame = item.frameData[frameIndex];
					if (frame) {
						ctx.drawImage(frame.flattenedCanvas, item.xPos, item.yPos, item.width, item.height);
					}
				} else {
					ctx.drawImage(item.image, item.xPos, item.yPos, item.width, item.height);
				}
			}
			let nextTimelineValue = (i === timeline.length - 1 ? maxDuration : timeline[i + 1]);
			let delay = nextTimelineValue - timelineValue;
			// let delay = timelineValue - lastTimelineValue;
			// lastTimelineValue = timelineValue;
			encoder.setDelay(delay * 10);
			encoder.addFrame(ctx);
		}
		encoder.finish();
		const buffer = encoder.out.getData();
		return {
			isAnimated: true,
			buffer: buffer
		};
	}
}

function mergeImages(items) {
	return new Promise((resolve, reject) => {
		let itemsToLoad = items.length;
		let itemsLoaded = 0;
		let parsedItems = [];
		let gifItems = [];
		for (let i = 0; i < items.length; i++) {
			let item = items[i];
			let pathname = url.parse(item.image_url).pathname;
			getContentType(item.image_url).then(contentType => {
				if (contentType == 'image/gif') {
					loadCompiledFrameData(item.image_url, item.image_width, item.image_height)
					.then((frameData) => {
						parsedItems.push({
							isGifItem: true,
							order: i,
							frameData: frameData,
							lastAddedFrame: -1,
							xPos: item.image_x_location,
							yPos: item.image_y_location,
							width: item.image_width,
							height: item.image_height
						});
						incrementItemsLoaded();
					}).catch((error) => {
						console.error('Failed load item. url=' + item.image_url+'\nError='+error.stack);
						incrementItemsLoaded();
					});
				} else {
					const image = new Image();
					image.onload = function () {
						parsedItems.push({
							isImageItem: true,
							order: i,
							image: image,
							xPos: item.image_x_location,
							yPos: item.image_y_location,
							width: item.image_width,
							height: item.image_height
						});
						incrementItemsLoaded();
					}
					image.onerror = function (error) {
						console.error(`image.onerror - The URL response\'s content is not a valid image! Failed load item. URL=${item.image_url}, Error=${error.stack}`);
						incrementItemsLoaded();
					}
					image.src = item.image_url;
				}
			}).catch((error) => {
				console.error(`'getContentType' (inside 'mergeImages') - Error retrieving the content and its type. Probably due to invlid/broken URL (URL=${item.image_url}), Error=${error.stack}`);
				incrementItemsLoaded();
			});
		}
		function incrementItemsLoaded() {
			itemsLoaded++;
			if (itemsLoaded === itemsToLoad) {
				resolve(mergeParsedItems(parsedItems));
			}
		}
	});
}

module.exports = mergeImages;