export interface MergeItem {
	image_url: string,
	image_x_location: number,
	image_y_location: number,
	image_width: number,
	image_height: number
};

export interface MergeResult {
	buffer: Buffer,
	isAnimated: boolean
}

export default function imageMerger(items: Array<MergeItem>): Promise<MergeResult>;