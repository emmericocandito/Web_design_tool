declare namespace GlobalMixins {
    interface TilingSprite {
        _canvasPattern: CanvasPattern;
    }
}
