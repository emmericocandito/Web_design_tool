# @pixi/filter-blur

## Installation

```bash
npm install @pixi/filter-blur
```

## Usage

```js
import '@pixi/filter-blur';
```