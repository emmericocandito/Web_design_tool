# @pixi/filter-alpha

## Installation

```bash
npm install @pixi/filter-alpha
```

## Usage

```js
import '@pixi/filter-alpha';
```