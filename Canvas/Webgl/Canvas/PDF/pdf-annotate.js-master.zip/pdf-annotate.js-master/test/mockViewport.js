export default function mockViewport(width = 100, height = 100, scale = 1, rotation = 0) {
  return {
    width, height, scale, rotation
  };
}

