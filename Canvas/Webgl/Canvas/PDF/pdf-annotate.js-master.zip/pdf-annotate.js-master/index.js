import PDFJSAnnotate from './src/PDFJSAnnotate';

export default PDFJSAnnotate;
