### Drawing

A `drawing` annotation is used to render free form drawing.

```js
{
  "class": "Annotation",
  "type": "drawing",
  "page": 1,
  "uuid": "2748a2d6-4089-4f63-b3b8-a61910487bdb",
  "color": "000000",
  "width": 1,
  "lines": [
    [113, 81],
    [115, 80],
    [119, 79],
    [123, 77],
    [126, 75]
  ]
}
```
