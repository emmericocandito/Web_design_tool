### Area

An `area` annotation is a free hand rectangle.

```js
{
  "class": "Annotation",
  "type": "area",
  "page": 1,
  "uuid": "839f4817-c82d-4620-a59b-6408b1dc0855",
  "color": "FF0000",
  "rectangles": [
    {
      "height": 75,
      "width": 150,
      "x": 19,
      "y": 37
    }
  ]
}
```
