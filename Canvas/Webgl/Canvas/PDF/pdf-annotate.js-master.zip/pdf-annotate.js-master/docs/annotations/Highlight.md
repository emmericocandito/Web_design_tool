### Highlight

A `highlight` annotation is used to highlight text.

```js
{
  "class": "Annotation",
  "type": "highlight",
  "page": 1,
  "uuid": "99c84974-b899-4de9-8c6c-28e541c03db8",
  "color": "FFFF00",
  "rectangles": [
    {
      "height": 12,
      "width": 335,
      "x": 188,
      "y": 189
    },
    {
      "height": 12,
      "width": 431,
      "x": 72,
      "y": 205
    }
  ]
}
```
