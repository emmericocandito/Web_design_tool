package com.groupdocs.ui.annotation.util.directory;

/**
 * IDirectoryUtils
 * Compare and sort file types - folders first
 * @author Aspose Pty Ltd
 */
public interface IDirectoryUtils {

    String getPath();
}
