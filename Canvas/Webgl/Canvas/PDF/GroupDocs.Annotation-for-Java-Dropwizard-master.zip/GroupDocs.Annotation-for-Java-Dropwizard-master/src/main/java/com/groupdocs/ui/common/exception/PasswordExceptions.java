package com.groupdocs.ui.common.exception;

public class PasswordExceptions {
    public static final String PASSWORD_REQUIRED = "Password Required";
    public static final String INCORRECT_PASSWORD = "Incorrect password";
}
