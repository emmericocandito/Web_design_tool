export class ObjectWriter {

    /**
     * Translates an object into its bytes repreesentation
     * */
    public static writeObject(obj: any): number[] {
        return []
    }
}
