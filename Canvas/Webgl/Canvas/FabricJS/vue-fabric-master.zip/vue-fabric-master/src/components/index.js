import Fabric from './fabric';
// const App = () => import(/* webpackChunkName: "frame" */ './image-model.vue');

export { Fabric };
