<?php global $lumise;
?>
<footer class="footer">
    <div class="container">
      
      
      <!-----  <div class="footer_content">
            <a href="http://italy.websitedesignbd.com/" class="footer_logo"><img src="Upload/companylogo.png"></a>
            <p>
                Add:Italy.<br>
                Email: <a href="mailto:contact@lumise.com" target="_blank">contact@italy.com</a><br>
                Help: <a href="http://italy.websitedesignbd.com/" target="_blank">help.italy.com</a>
            </p>
            <ul class="tsd_social">
                <li><a href="https://facebook.com/" target="_blank" class="fa fa-facebook"></a></li>
                <li><a href="https://twitter.com/" target="_blank" class="fa fa-twitter"></a></li>
                <li><a href="https://instagram.com/" target="_blank" class="fa fa-instagram"></a></li>
            </ul>
        </div>
        <div class="footer_content">
            <h4>Custom care</h4>
            <ul class="link">
                <li><a href="#">About Us</a></li>
                <li><a href="#">Help Center</a></li>
                <li><a href="#">Features</a></li>
                <li><a href="#">Pricing</a></li>
            </ul>
        </div>
        <div class="footer_content">
            <h4>More</h4>
            <ul class="link">
                <li><a href="#">Blog</a></li>
                <li><a href="#">FAQs</a></li>
                <li><a href="#">Testimonial</a></li>
                <li><a href="#">Contact</a></li>
            </ul>
        </div>
        <div class="footer_content">
            <h4>Newsletter</h4>
            <p>Sign up our newsletter to receive updates from our store, promotions, and events.</p>
            <form action="" class="form-sub">
                <input type="text" placeholder="Email address here">
                <input type="submit" value="Send">
            </form>
        </div>
    </div>
    ------->
    <div class="container">
        <div class="copyright">
            <p>Copyright © 2020 <a href="https://www.getimpressed.eu/en" target="_blank">GET IMPRESSED</a> | <a href="https://www.getimpressed.eu/en">Privacy &amp; policy</a><a href="https://www.getimpressed.eu/en">Term of services</a></p>
        </div>
    </div>
</footer>
</body>
</html>