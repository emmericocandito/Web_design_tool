<?php

global $lumise;

echo 434334;