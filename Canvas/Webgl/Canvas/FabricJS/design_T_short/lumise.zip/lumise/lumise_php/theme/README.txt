Copy all your files that you changed in the folder /theme to avoid being overwritten when updating core.

ALLOW

/head.php
/header.php
/footer.php
/assets/
/index.php
/cancel.php
/products.php
/product.php
/login.php
/add-cart.php
/placeorder.php
/process_checkout.php
/stats.php
/success.php
/templates.php


NOT ALLOW
/autoload.php
/php_connector.php
/editor.php
/info.php
/admin.php
/paypal_ipn.php
/core
/installer
/inc
