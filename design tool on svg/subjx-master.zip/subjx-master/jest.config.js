// eslint-disable-next-line no-undef
module.exports = {
    setupFilesAfterEnv: ['./jest.setup.js']
};